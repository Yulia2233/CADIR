"""SimpleCAD API: a simplified OCP-native Python CAD modeling API."""

from .core import (
    # 核心类
    CoordinateSystem,
    SimpleWorkplane,
    Vertex,
    Edge,
    Wire,
    Face,
    Solid,
    Compound,
    AnyShape,
    TaggedMixin,
    # 坐标系函数
    get_current_cs,
    WORLD_CS,
)

from .operations import (
    # 基础几何创建
    make_angle_arc_redge,
    make_angle_arc_rwire,
    make_box_rsolid,
    make_circle_redge,
    make_circle_rface,
    make_circle_rwire,
    make_cone_rsolid,
    make_cylinder_rsolid,
    make_face_from_sketch_rface,
    make_face_from_wire_rface,
    make_face_from_wires_rface,
    make_helix_redge,
    make_helix_rwire,
    make_line_redge,
    make_point_rvertex,
    make_polyline_rwire,
    make_rectangle_rface,
    make_rectangle_rwire,
    make_segment_redge,
    make_segment_rwire,
    make_sphere_rsolid,
    make_sketch_rsketch,
    make_spline_redge,
    make_spline_rwire,
    make_three_point_arc_redge,
    make_three_point_arc_rwire,
    make_wire_from_edges_rwire,
    make_wire_from_sketch_rwire,
    make_material_rmaterial,
    make_placement_rplacement,
    identity_placement_rplacement,
    make_part_rpart,
    assign_material_rpart,
    make_assembly_rassembly,
    add_component_rassembly,
    place_component_rassembly,
    make_compound_from_assembly_rcompound,
    make_face_connector_rconnector,
    make_edge_connector_rconnector,
    make_vertex_connector_rconnector,
    make_placement_connector_rconnector,
    add_connector_rpart,
    add_connector_rassembly,
    forward_connector_rassembly,
    make_connector_ref_rconnectorref,
    make_scalar_limit_rscalarlimit,
    ground_component_rassembly,
    unground_component_rassembly,
    add_fixed_constraint_rassembly,
    add_revolute_constraint_rassembly,
    add_prismatic_constraint_rassembly,
    add_gear_constraint_rassembly,
    add_belt_constraint_rassembly,
    add_rack_pinion_constraint_rassembly,
    solve_assembly_constraints_rassembly,
    measure_constraint_residual_rconstraintresidual,
    inspect_assembly_constraints_rconstraintreport,
    add_point_rsketch,
    add_circle_rsketch,
    add_line_rsketch,
    add_arc_rsketch,
    add_bspline_rsketch,
    constrain_angle_rsketch,
    constrain_coincident_rsketch,
    constrain_collinear_rsketch,
    constrain_concentric_rsketch,
    constrain_connect_rsketch,
    constrain_diameter_rsketch,
    constrain_distance_rsketch,
    constrain_distance_x_rsketch,
    constrain_distance_y_rsketch,
    constrain_equal_length_rsketch,
    constrain_equal_radius_rsketch,
    constrain_fix_rsketch,
    constrain_horizontal_rsketch,
    constrain_length_rsketch,
    constrain_midpoint_rsketch,
    constrain_parallel_rsketch,
    constrain_perpendicular_rsketch,
    constrain_point_on_rsketch,
    constrain_radius_rsketch,
    constrain_symmetric_rsketch,
    constrain_tangent_rsketch,
    constrain_vertical_rsketch,
    get_sketch_entity_rsketchref,
    get_sketch_point_rsketchref,
    inspect_sketch_rsketchresult,
    # 变换操作
    mirror_shape,
    rotate_shape,
    translate_shape,
    # 3D操作
    extrude_rsolid,
    helical_sweep_rsolid,
    loft_rsolid,
    revolve_rsolid,
    sweep_rsolid,
    # 标签和选择
    apply_tag,
    list_tags,
    select_edges_by_tag,
    select_faces_by_tag,
    # 布尔运算
    cut_rsolid,
    make_2d_cut_rface,
    intersect_rsolid,
    make_2d_intersect_rface,
    union_rsolid,
    make_2d_union_rface,
    # 导出
    export_step,
    export_stl,
    render_screenshot_rpath,
    # 高级特征操作
    chamfer_rsolid,
    fillet_rsolid,
    shell_rsolid,
    # 其他
    linear_pattern_rsolidlist,
    radial_pattern_rsolidlist,
)

from .evolve import (
    # 其他
    make_n_hole_flange_rsolid,
    make_naca_propeller_blade_rsolid,
    make_threaded_rod_rsolid,
)

from .graph import GraphSession, suspend_graph_recording
from .serializer import export_graph_json, import_graph_json, replay_graph
from .serializer import export_session_json, import_session_json
from .serializer import export_model_json, import_model_json, replay_model_json
from .expr import (
    Expr,
    Var,
    Const,
    ExpressionGraph,
    acos,
    asin,
    atan,
    atan2,
    const,
    cos,
    sin,
    sqrt,
    tan,
    var,
)
from .math import BSplineFitResult, fit_cubic_bspline_control_points
from .product import (
    Assembly,
    Component,
    Connector,
    ConnectorAnchor,
    ConnectorRef,
    Constraint,
    ConstraintReport,
    ConstraintResidual,
    GeometryRef,
    ConstraintResidual,
    Material,
    Part,
    Placement,
    ScalarLimit,
)
from .sketch import Sketch, SketchConstraint, SketchConstraintDiagnostic, SketchRef, SketchSolveResult
from .topology import SemanticDelta, SemanticRef
from .errors import SimpleCADError

from . import ql
from . import math
from . import std
from . import translator
from . import verifier

# Avoid advertising internal implementation submodules from the top-level package
# namespace. They remain importable as `simplecadapi.<module>` when needed.
for _name in ("tracking", "autotag", "topology", "graph", "serializer"):
    globals().pop(_name, None)

__author__ = "SimpleCAD API Team"
__description__ = "Simplified OCP-native CAD modeling Python API"

# 便于使用的别名
Workplane = SimpleWorkplane

# 创建函数别名
create_angle_arc = make_angle_arc_redge
create_angle_arc_wire = make_angle_arc_rwire
create_arc = make_three_point_arc_redge
create_arc_wire = make_three_point_arc_rwire
create_box = make_box_rsolid
create_circle_edge = make_circle_redge
create_circle_face = make_circle_rface
create_circle_wire = make_circle_rwire
create_cylinder = make_cylinder_rsolid
create_face_from_wire = make_face_from_wire_rface
create_face_from_wires = make_face_from_wires_rface
create_helix = make_helix_redge
create_helix_wire = make_helix_rwire
create_line = make_line_redge
create_point = make_point_rvertex
create_polyline_wire = make_polyline_rwire
create_rectangle_face = make_rectangle_rface
create_rectangle_wire = make_rectangle_rwire
create_segment = make_segment_redge
create_segment_wire = make_segment_rwire
create_sphere = make_sphere_rsolid
create_spline = make_spline_redge
create_spline_wire = make_spline_rwire
create_wire_from_edges = make_wire_from_edges_rwire

# 变换操作别名
rotate = rotate_shape
translate = translate_shape

# 3D操作别名
extrude = extrude_rsolid
revolve = revolve_rsolid

# 布尔运算别名
cut = cut_rsolid
intersect = intersect_rsolid
union = union_rsolid

# 导出别名
to_step = export_step
to_stl = export_stl

__all__ = [
    # 核心类
    "CoordinateSystem",
    "SimpleWorkplane",
    "Workplane",
    "Vertex",
    "Edge",
    "Wire",
    "Face",
    "Solid",
    "Compound",
    "AnyShape",
    "TaggedMixin",
    # 坐标系
    "get_current_cs",
    "WORLD_CS",
    # 基础几何创建
    "make_angle_arc_redge",
    "make_angle_arc_rwire",
    "make_box_rsolid",
    "make_circle_redge",
    "make_circle_rface",
    "make_circle_rwire",
    "make_cone_rsolid",
    "make_cylinder_rsolid",
    "make_face_from_sketch_rface",
    "make_face_from_wire_rface",
    "make_face_from_wires_rface",
    "make_helix_redge",
    "make_helix_rwire",
    "make_line_redge",
    "make_point_rvertex",
    "make_polyline_rwire",
    "make_rectangle_rface",
    "make_rectangle_rwire",
    "make_segment_redge",
    "make_segment_rwire",
    "make_sphere_rsolid",
    "make_sketch_rsketch",
    "make_spline_redge",
    "make_spline_rwire",
    "make_three_point_arc_redge",
    "make_three_point_arc_rwire",
    "make_wire_from_edges_rwire",
    "make_wire_from_sketch_rwire",
    "make_material_rmaterial",
    "make_placement_rplacement",
    "identity_placement_rplacement",
    "make_part_rpart",
    "assign_material_rpart",
    "make_assembly_rassembly",
    "add_component_rassembly",
    "place_component_rassembly",
    "make_compound_from_assembly_rcompound",
    "make_face_connector_rconnector",
    "make_edge_connector_rconnector",
    "make_vertex_connector_rconnector",
    "make_placement_connector_rconnector",
    "add_connector_rpart",
    "add_connector_rassembly",
    "forward_connector_rassembly",
    "make_connector_ref_rconnectorref",
    "make_scalar_limit_rscalarlimit",
    "ground_component_rassembly",
    "unground_component_rassembly",
    "add_fixed_constraint_rassembly",
    "add_revolute_constraint_rassembly",
    "add_prismatic_constraint_rassembly",
    "add_gear_constraint_rassembly",
    "add_belt_constraint_rassembly",
    "add_rack_pinion_constraint_rassembly",
    "solve_assembly_constraints_rassembly",
    "measure_constraint_residual_rconstraintresidual",
    "inspect_assembly_constraints_rconstraintreport",
    # Sketch construction and constraints
    "add_point_rsketch",
    "add_circle_rsketch",
    "add_line_rsketch",
    "add_arc_rsketch",
    "add_bspline_rsketch",
    "constrain_angle_rsketch",
    "constrain_coincident_rsketch",
    "constrain_collinear_rsketch",
    "constrain_concentric_rsketch",
    "constrain_connect_rsketch",
    "constrain_diameter_rsketch",
    "constrain_distance_rsketch",
    "constrain_distance_x_rsketch",
    "constrain_distance_y_rsketch",
    "constrain_equal_length_rsketch",
    "constrain_equal_radius_rsketch",
    "constrain_fix_rsketch",
    "constrain_horizontal_rsketch",
    "constrain_length_rsketch",
    "constrain_midpoint_rsketch",
    "constrain_parallel_rsketch",
    "constrain_perpendicular_rsketch",
    "constrain_point_on_rsketch",
    "constrain_radius_rsketch",
    "constrain_symmetric_rsketch",
    "constrain_tangent_rsketch",
    "constrain_vertical_rsketch",
    "get_sketch_entity_rsketchref",
    "get_sketch_point_rsketchref",
    "inspect_sketch_rsketchresult",
    # 变换操作
    "mirror_shape",
    "rotate_shape",
    "translate_shape",
    # 3D操作
    "extrude_rsolid",
    "helical_sweep_rsolid",
    "loft_rsolid",
    "revolve_rsolid",
    "sweep_rsolid",
    # 标签和选择
    "apply_tag",
    "list_tags",
    "select_edges_by_tag",
    "select_faces_by_tag",
    # 布尔运算
    "cut_rsolid",
    "make_2d_cut_rface",
    "intersect_rsolid",
    "make_2d_intersect_rface",
    "union_rsolid",
    "make_2d_union_rface",
    # 导出
    "export_step",
    "export_stl",
    "replay_model_json",
    "render_screenshot_rpath",
    # 高级特征操作
    "chamfer_rsolid",
    "fillet_rsolid",
    "shell_rsolid",
    # 其他
    "linear_pattern_rsolidlist",
    "math",
    "make_n_hole_flange_rsolid",
    "make_naca_propeller_blade_rsolid",
    "make_threaded_rod_rsolid",
    "radial_pattern_rsolidlist",
    "ql",
    "std",
    "translator",
    "verifier",
    # Graph/session + serialization APIs
    "GraphSession",
    "suspend_graph_recording",
    "export_graph_json",
    "import_graph_json",
    "replay_graph",
    "export_session_json",
    "import_session_json",
    "export_model_json",
    "import_model_json",
    "Expr",
    "Var",
    "Const",
    "ExpressionGraph",
    "BSplineFitResult",
    "acos",
    "asin",
    "atan",
    "atan2",
    "const",
    "cos",
    "sin",
    "sqrt",
    "tan",
    "var",
    "fit_cubic_bspline_control_points",
    "Sketch",
    "SketchConstraint",
    "SketchConstraintDiagnostic",
    "SketchRef",
    "SketchSolveResult",
    "SemanticRef",
    "SemanticDelta",
    "SimpleCADError",
    "Assembly",
    "Component",
    "Connector",
    "ConnectorAnchor",
    "ConnectorRef",
    "Constraint",
    "ConstraintReport",
    "ConstraintResidual",
    "GeometryRef",
    "Material",
    "Part",
    "Placement",
    "ScalarLimit",
    # 别名
    "create_angle_arc",
    "create_angle_arc_wire",
    "create_arc",
    "create_arc_wire",
    "create_box",
    "create_circle_edge",
    "create_circle_face",
    "create_circle_wire",
    "create_cylinder",
    "create_face_from_wire",
    "create_face_from_wires",
    "create_helix",
    "create_helix_wire",
    "create_line",
    "create_point",
    "create_polyline_wire",
    "create_rectangle_face",
    "create_rectangle_wire",
    "create_segment",
    "create_segment_wire",
    "create_sphere",
    "create_spline",
    "create_spline_wire",
    "create_wire_from_edges",
    "cut",
    "extrude",
    "intersect",
    "revolve",
    "rotate",
    "to_step",
    "to_stl",
    "translate",
    "union",
]
